
const sections = document.querySelectorAll('section');
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, { threshold: 0.1 });

sections.forEach(section => observer.observe(section));

const today = new Date().toISOString().split('T')[0];
document.getElementById('date').setAttribute('min', today);

document.getElementById('bookingForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const name = document.getElementById('name').value;
  const date = document.getElementById('date').value;
  const dept = document.getElementById('department').value;
  document.getElementById('confirmation').innerText =
    `Thank you, ${name}! Appointment booked for ${dept} on ${date}.`;
  this.reset();
});
