package view;

public class LoginView {
    public void showSuccess() {
        System.out.println("Login successful!");
    }

    public void showFailure() {
        System.out.println("Login failed. Invalid credentials.");
    }
}
