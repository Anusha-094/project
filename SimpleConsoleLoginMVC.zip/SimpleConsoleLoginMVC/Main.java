import java.util.Scanner;

import controller.LoginController;
import model.User;
import service.LoginService;
import view.LoginView;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter username:");
        String uname = scanner.nextLine();

        System.out.println("Enter password:");
        String pwd = scanner.nextLine();

        User user = new User(uname, pwd);
        LoginView view = new LoginView();
        LoginService service = new LoginService();

        LoginController controller = new LoginController(user, view, service);
        controller.login();

        scanner.close();
    }
}
