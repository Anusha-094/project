package controller;

import model.User;
import service.LoginService;
import view.LoginView;

public class LoginController {
    private User user;
    private LoginView view;
    private LoginService service;

    public LoginController(User user, LoginView view, LoginService service) {
        this.user = user;
        this.view = view;
        this.service = service;
    }

    public void login() {
        boolean isAuthenticated = service.authenticate(user.getUsername(), user.getPassword());
        if (isAuthenticated) {
            view.showSuccess();
        } else {
            view.showFailure();
        }
    }
}
